package com.oozinoz.applications;

//���� GUI ����
public class RocketTest{

	public static void main(String[] args) {
		RocketUI rocketUI=new RocketUI();
		rocketUI.getRocketUI();
		
	}

}