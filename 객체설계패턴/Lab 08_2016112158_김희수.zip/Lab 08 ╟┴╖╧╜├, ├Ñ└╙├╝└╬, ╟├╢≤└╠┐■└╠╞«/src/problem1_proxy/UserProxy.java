package problem1_proxy;

public interface UserProxy {
    User getUser();
}
