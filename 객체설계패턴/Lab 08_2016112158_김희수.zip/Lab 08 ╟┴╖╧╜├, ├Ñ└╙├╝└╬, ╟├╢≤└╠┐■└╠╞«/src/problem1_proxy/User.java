package problem1_proxy;

public interface User {
    void checkOut();
}
