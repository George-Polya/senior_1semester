package problem2_chain;

public interface Image {
    String process();
}
