package problem2_chain;

public class LS implements Image {
    @Override
    public String process() {
        return "LS";
    }
}
