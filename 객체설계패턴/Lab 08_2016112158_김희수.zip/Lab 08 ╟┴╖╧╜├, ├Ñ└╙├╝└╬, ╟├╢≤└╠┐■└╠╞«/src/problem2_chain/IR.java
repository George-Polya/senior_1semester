package problem2_chain;

public class IR implements Image {

    public String process() {
        return "IR";
    }

}
